package Housemanager.entities.Enums;

public enum ResidentType {
    CHILD, 
    PET, 
    ELEVATOR_USER, 
    REGULAR
}